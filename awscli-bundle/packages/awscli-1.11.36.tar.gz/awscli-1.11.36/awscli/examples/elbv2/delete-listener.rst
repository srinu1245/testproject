**To delete a listener**

This example deletes the specified listener.

Command::

  aws elbv2 delete-listener --listener-arn arn:aws:elasticloadbalancing:ua-west-2:123456789012:listener/app/my-load-balancer/50dc6c495c0c9188/f2f7dc8efc522ab2
