**To import a Swagger template and create an API in the specified region**

Command::

  aws apigateway import-rest-api --body 'file:///path/to/API_Swagger_template.json' --region us-west-2

